create definer = root@localhost view actors_details as
select `neo_ooh`.`actors`.`id`                       AS `id`,
       `ac`.`ancestor_id`                            AS `parent_id`,
       coalesce(`asp`.`is_group`, 0)                 AS `parent_is_group`,
       count(`acc`.`descendant_id`)                  AS `direct_children_count`,
       coalesce((select group_concat(`a`.`name` order by `ac`.`depth` DESC separator '/')
                 from (`neo_ooh`.`actors` `a`
                          join `neo_ooh`.`actors_closures` `ac`
                               on (((`ac`.`ancestor_id` = `a`.`id`) and (`a`.`is_group` = 1))))
                 where ((`ac`.`descendant_id` = `a`.`id`) and (`ac`.`ancestor_id` <> `a`.`id`))
                 group by `ac`.`descendant_id`), '') AS `path_names`,
       coalesce((select group_concat(`a`.`id` order by `ac`.`depth` DESC separator '/')
                 from (`neo_ooh`.`actors` `a`
                          join `neo_ooh`.`actors_closures` `ac`
                               on (((`ac`.`ancestor_id` = `a`.`id`) and (`a`.`is_group` = 1))))
                 where ((`ac`.`descendant_id` = `a`.`id`) and (`ac`.`ancestor_id` <> `a`.`id`))
                 group by `ac`.`descendant_id`), '') AS `path_ids`
from (((`neo_ooh`.`actors` left join `neo_ooh`.`actors_closures` `ac` on ((
        (`ac`.`descendant_id` = `neo_ooh`.`actors`.`id`) and
        (`ac`.`depth` = 1)))) left join `neo_ooh`.`actors_closures` `acc` on ((
        (`acc`.`ancestor_id` = `neo_ooh`.`actors`.`id`) and (`acc`.`depth` > 0))))
         left join `neo_ooh`.`actors` `asp` on ((`asp`.`id` = `ac`.`ancestor_id`)))
group by `neo_ooh`.`actors`.`id`, `ac`.`ancestor_id`;

